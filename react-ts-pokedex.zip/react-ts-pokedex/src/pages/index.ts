export { Home } from './Home';
export { Pokedex } from "./Pokedex";
export { PokeDetail } from "./PokeDetail";

