import styled from 'styled-components'
export const Container = styled.div`
  max-width: 100vw;
  min-height: 100vh;
  background-color: #f7f7f7;
`
